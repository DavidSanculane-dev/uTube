﻿namespace YoutubeDownloader.Core.Resolving;

public enum QueryResultKind
{
    Video,
    Playlist,
    Channel,
    Search,
    Aggregate
}
