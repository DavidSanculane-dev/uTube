﻿namespace YoutubeDownloader.Views.Dialogs;

public partial class DownloadSingleSetupView
{
    public DownloadSingleSetupView()
    {
        InitializeComponent();
    }
}
